create
    definer = root@localhost procedure get_category_by_id(IN categoryID int)
BEGIN

    SELECT *

    FROM category

    where category.categoryID = categoryId;

    END;

