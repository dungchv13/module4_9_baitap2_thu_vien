create
    definer = root@localhost procedure create_product(IN name varchar(50), IN provider varchar(50),
                                                      IN description varchar(255), IN price double, IN quantity int,
                                                      IN image varchar(255), IN categoryID int)
begin
    insert into products(productName, provide, productDescription, productPrice, productQuantity, productImage, categoryId) values (name,provider,description,price,quantity,image,categoryID);

end;

